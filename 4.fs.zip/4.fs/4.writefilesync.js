const fs = require('fs');

const data = "파일을 바꿔보겠습니다. 비가 오고 춥습니다. 4월 중순인데 체감 온도가 0도에 가깝씁니다."

console.log("파일 읽기 전");

fs.writeFileSync('example.txt', data, {encoding:'utf8', flag: 'a'});

console.log(data);
console.log("파일 읽은 후");
