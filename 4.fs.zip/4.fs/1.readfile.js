// 별다른 말이 없다면 common js 방식

const fs = require('fs');

// function myCallBackFunction (err, data) {
//     if (err) {
//         console.error(err,data);
//     } else {
//         console.log("에러가 없음", data);
//     }
// }

// fs.readFile('example.txt', 'utf8', myCallBackFunction);

console.log("파일 읽기 전");

// fs.readFile('example.txt', 'utf8', ( err, data) => {
    
//         if (err) {
//             console.error(err,data);
//         } else {
//             console.log("에러가 없음", data);
//         }
// });


const data = fs.readFileSync ( 'example.txt', 'utf8');
console.log("데이터는: ", data);


console.log("파일 읽은 후");
